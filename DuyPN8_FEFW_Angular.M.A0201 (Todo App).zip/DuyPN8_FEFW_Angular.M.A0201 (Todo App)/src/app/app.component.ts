
import { Template } from '@angular/compiler/src/render3/r3_ast';
import { Component } from '@angular/core';

// import { threadId } from 'worker_threads';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',

  styleUrls: ['./app.component.scss'],

})
export class AppComponent {
  title = 'todoApp';
  task: string = ""
  listTodo: string[] = []
  listComplete: string[] = []

  addTodoItem() {
    if (this.task == '') {
    }
    else {
        this.listTodo.push(this.task);
        this.task = '';
    }
  }

  onKeyPress(){
    this.addTodoItem()
  }
  onClick(){
    this.addTodoItem();
  }

  checkComplete(item: string){
    return this.listComplete.includes(item)
  }

  clickToDone(item:string){
    console.log('clicked')
    this.listComplete.push(item)
  }

  deleteTask(index:number) {
    this.listTodo.splice(index, 1);
}
  
}

