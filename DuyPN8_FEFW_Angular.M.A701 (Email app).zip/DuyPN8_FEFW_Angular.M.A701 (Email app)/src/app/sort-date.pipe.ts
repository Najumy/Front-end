import { Pipe, PipeTransform } from '@angular/core';
import { Message } from './message';

@Pipe({
  name: 'sortDate',
})
export class SortDatePipe implements PipeTransform {
  transform(list: Message[]): any {
    let sortedList = list.sort(function (a, b): number {
      if (a['date'] > b['date']) {
        return 1;
      }
      if (a['date'] < b['date']) {
        return -1;
      }
      return 0;
    });
    return sortedList;
  }
}
