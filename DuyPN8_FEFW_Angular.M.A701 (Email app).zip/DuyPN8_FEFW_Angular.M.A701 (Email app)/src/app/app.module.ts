import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmailappComponent } from './yourmessage/yourmessage.component';
import { FolderComponent } from './yourmessage/folder/folder.component';

import { MenuComponent } from './yourmessage/menu/menu.component';
import { LetterComponent } from './yourmessage/letter/letter.component';
import { ContactsComponent } from './contacts/contacts.component';
import { SortDatePipe } from './sort-date.pipe';
import { FormsModule } from '@angular/forms';
import { PreferencesComponent } from './preferences/preferences.component';

@NgModule({
  declarations: [
    AppComponent,
    EmailappComponent,
    FolderComponent,
    MenuComponent,
    LetterComponent,
    ContactsComponent,
    SortDatePipe,
    PreferencesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
