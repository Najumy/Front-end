import { FolderComponent } from './yourmessage/folder/folder.component';
import { MenuComponent } from './yourmessage/menu/menu.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContactsComponent } from './contacts/contacts.component';
import { LetterComponent } from './yourmessage/letter/letter.component';
import { PreferencesComponent } from './preferences/preferences.component';

const routes: Routes = [
  { path: '', redirectTo: 'parent/messages/inbox', pathMatch: 'full' },
  {
    path: 'parent',
    component: MenuComponent,
    children: [
      {
        path: 'messages/:folderName',
        component: FolderComponent,
        children: [{ path: ':id', component: LetterComponent }],
      },
      { path: 'contact', component: ContactsComponent },
      { path: 'pref', component: PreferencesComponent }
    ],
  },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
