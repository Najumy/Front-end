import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-yourmessage',
  templateUrl: './yourmessage.component.html',
  styleUrls: ['./yourmessage.component.css'],
})
export class EmailappComponent implements OnInit {
  folders: string[] = [
    'inbox',
    'finance',
    'travel',
    'personal',
    'spam',
    'draft',
    'sent',
  ];

  constructor(private userMess: UserService, private route: ActivatedRoute) {}

  ngOnInit(): void {}
}
