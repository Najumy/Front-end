import { Message } from 'src/app/message';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from 'src/app/user.service';

@Component({
  selector: 'app-letter',
  templateUrl: './letter.component.html',
  styleUrls: ['./letter.component.css'],
})
export class LetterComponent implements OnInit {
  idMess: any;
  message: Message | undefined;
  constructor(
    private route: ActivatedRoute,
    private messService: UserService
  ) {}

  ngOnInit(): void {
    this.route.paramMap.
    subscribe((params) => {
      this.idMess = 
      params.get('id');
      this.message = this.
      messService.getMessageById(
        this.idMess,
        this.messService.messInCurrentFolder
      );
    });
  }
}
