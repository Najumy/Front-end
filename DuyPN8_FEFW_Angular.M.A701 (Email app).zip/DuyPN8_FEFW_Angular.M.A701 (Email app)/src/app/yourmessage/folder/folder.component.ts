import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Message } from 'src/app/message';
import { UserService } from 'src/app/user.service';

@Component({
  selector: 'app-folder',
  templateUrl: './folder.component.html',
  styleUrls: ['./folder.component.css'],
})
export class FolderComponent implements OnInit {
  messageUser: Message[] = this.userMess.getMessageByUser('myself@angular.dev');
  folders: string[] = [
    'inbox',
    'finance',
    'travel',
    'personal',
    'spam',
    'draft',
    'sent',
  ];
  filterMessage: Message[] = [];
  currentFolder: string | undefined;
 
  constructor(private userMess: UserService, private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe((params) => {
      this.currentFolder = params.get('folderName') as string;
      this.filterMessage = this.messageUser.filter(
        (mess) => mess.folder === this.currentFolder
      );
      this.userMess.messInCurrentFolder = this.filterMessage;
    });
  }

  getMessByFolder(folder: string) {
    
  }

 
}
