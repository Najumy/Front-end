
import { Component, EventEmitter, OnInit, Output } from '@angular/core';


interface Todo {
  name: string;
  isCompleted: boolean;
}
@Component({
  selector: 'app-input',
  templateUrl: './input.component.html',
  styleUrls: ['./input.component.scss']
})
export class InputComponent implements OnInit {
  @Output() inpValue = new EventEmitter<Todo>()
  // inp: string = '';
  // title = 'todoApp3';
  task: string = ''

  constructor() { }

  ngOnInit(): void {
  }

  addTodoItem() {
    let object = { name: this.task.trim(), isCompleted: false }
    this.task = ''
    this.inpValue.emit(object)
  }

  onKeyPress() {
    this.addTodoItem()
    // 
    // return this.listTodo
    // }

  }
  onClick() {
    this.addTodoItem();
    // return this.listTodo
    // this.inpValue.emit(this.task)
  }
}
