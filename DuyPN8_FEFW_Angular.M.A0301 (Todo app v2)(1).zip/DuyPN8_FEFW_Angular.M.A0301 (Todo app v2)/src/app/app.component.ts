import { Component } from '@angular/core';

interface Todo {
  name: string;
  isCompleted: boolean;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {


  // listTestParent: string[] = ['Hieu', 'Hung', 'Thao', 'Hien']

  task: string = ""
  listTodo: Todo[] = []



  // checkComplete(item: string) {
  //   return this.listComplete.includes(item)
  // }


  clickToDone(task: Todo) {
    this.listTodo.push(task as never)
  }

  deleteTask(index: number) {
    this.listTodo.splice(index, 1)
  }

 completeTodo(index: number){

 }
}
