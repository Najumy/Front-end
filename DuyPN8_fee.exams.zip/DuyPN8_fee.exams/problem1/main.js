let input =document.querySelector(".input")
let inputError = document.querySelector(".error-alert")
const btnAdd =document.querySelector(".btn-add")
const list = document.querySelector("ul")

//reset input

//add task to list
function addTask(){
    const li=document.createElement("li");
    const btnDel = document.createElement ("i");
    let text = document.createTextNode("\u00D7");
    btnDel.appendChild(text);
    btnDel.className="delete"
    li.appendChild(document.createTextNode(input.value));
    list.appendChild(li);
    li.appendChild(btnDel);
    input.value =""
    
    
    
}
function addTaskbyEnter(e){
   if(e.keycode===13){
       if(input.value.length>0){
           addTask();
       }
   }
}
function addTaskbyClick(){
    if(input.value.length >0 ){
        addTask();
        input.value.innerHTML=""
    }
}
function finishTask(){
    const com = document.createElement("i");
    if(task.target.tagName==="li"){
        task.target.classList.toggle("completed");
        const com = document.createTextNode(" (completed)");
        const btnDel= task.target.querySelector(".delete");
        if(task.target.classList.contains("completed")){
            task.target.insertBefore(com,btnDel);
        }
        task.style.backgroundColor = "aquamarine";
        
    }

}
function deleTask(){
   
  for(var i=0;i<btnDel.length;i++){
    btnDel[i].onclick =function(){
        var div=this.parentElement;
        div.style.display="none";
    }
  }
}


btnAdd.addEventListener("click",addTaskbyClick)
input.addEventListener("keypress",addTaskbyEnter)
list.addEventListener("click",finishTask)
btnDel.addEventListener("click",deleTask)
li.addEventListener('click',finishTask)
